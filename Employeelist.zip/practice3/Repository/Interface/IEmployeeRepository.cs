﻿using practice3.Model;
using System.Collections.Generic;

namespace practice3.Repository.Interface
{
    public interface IEmployeeRepository
    {
        List<EmployeeModel> GetAllEmployees();
        List<EmployeeModel> AddEmployee(EmployeeModel newemp);
        //List<EmployeeModel> EditEmployee(EmployeeModel Id);
        List<EmployeeModel> DelEmployee(int Id);
    }
}
