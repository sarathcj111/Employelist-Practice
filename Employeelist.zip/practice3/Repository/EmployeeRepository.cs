﻿using Microsoft.Extensions.Configuration;
using practice3.Helper;
using practice3.Model;
using practice3.Repository.Interface;
using System;
using System.Collections.Generic;

namespace practice3.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IConfiguration _config;
        private HelperClass _helper;
        public EmployeeRepository(IConfiguration config)
        {
            _config = config;
            _helper = new HelperClass();
        }

        private List<EmployeeModel> GenerateEmpList()
        {
            var emplist = new List<EmployeeModel>();

            for(var i = 0; i <= 100; i++)
            {
                if(_config.GetValue<int>($"Employee{i + 1}:EmpId") > 0)
                {
                    EmployeeModel emp = new EmployeeModel();
                    emp.EmpId = _config.GetValue<int>($"Employee{i + 1}:EmpId");
                    emp.EmpName = _config.GetValue<String>($"Employee{i + 1}:EmpName");
                    emp.Age = _config.GetValue<int>($"Employee{i + 1}:Age");
                    emp.Dept = _config.GetValue<String>($"Employee{i + 1}:Dept");
                    emplist.Add(emp);
                }
                else
                    break;
            }
            return emplist;
        }

        public List<EmployeeModel> GetAllEmployees()
        {
            return GenerateEmpList();
        }

        public List<EmployeeModel> AddEmployee(EmployeeModel newemp)
        {
            var emplist = GenerateEmpList();
            newemp.EmpId = emplist.Count + 1;
            emplist.Add(newemp);
            _helper.AddtoJson(newemp);
            return emplist;
        }

        public List<EmployeeModel> DelEmployee(int Id)
        {
            var emplist = GenerateEmpList();
            var emp = emplist.Find(x => x.EmpId == Id);
            emplist.Remove(emp);
            _helper.RemoveFromJson(emp);  /*The data gets removed at that particular instance while testing in postman. But doesnt get removed from json*/ 
            return emplist;
        }

        //public List<EmployeeModel> EditEmployee(EmployeeModel employee)
        //{
        //    var emplist = GenerateEmpList();
        //    var emp = emplist.Find(x => x.EmpId == employee.EmpId);
        //    emp.EmpName = employee.EmpName;
        //    emp.Age = employee.Age;
        //    emp.Dept = employee.Dept;
        //    return emplist;
        //}
    }
}
