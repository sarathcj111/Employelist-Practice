﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using practice3.Model;
using practice3.Repository.Interface;

namespace practice3.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        private readonly IEmployeeRepository _IEmployeeRepository;
        public EmployeeController(IEmployeeRepository iemployeeRepository)
        {
            _IEmployeeRepository = iemployeeRepository;
        }

        [HttpGet]
        [Route("getallemp")]
        public IActionResult GetAllEmployeesApi()
        {
            var emplist = _IEmployeeRepository.GetAllEmployees();
            return Ok(emplist);
        }

        [HttpPost]
        [Route("addemp")]
        public IActionResult AddEmployeeApi(EmployeeModel newemp)
        {
            var emplist = _IEmployeeRepository.AddEmployee(newemp);
            return Ok(emplist);
        }

        [HttpDelete]
        [Route("delemp/{Id}")]
        public IActionResult DelEmployeeApi(int Id)
        {
            var emplist = _IEmployeeRepository.DelEmployee(Id);
            return Ok(emplist);
        }

        //[HttpPut]
        //[Route("editemp/{Id}")]
        //public IActionResult EditEmployeeApi(EmployeeModel Id)
        //{
        //    var emplist = _IEmployeeRepository.EditEmployee(Id);
        //    return Ok(emplist);
        //}
    }
}

