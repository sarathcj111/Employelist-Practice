﻿namespace practice3.Model
{
    public class EmployeeModel
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int Age { get; set; }
        public string Dept { get; set; }
    }
}
